strat=(addSubset(inputGraphs) >> repeat[2](inputRules))

dg=dgRuleComp(inputGraphs, strat)
dg.calc()
dg.print()

postSection("Rule")
for r in inputRules:
    r.print()
