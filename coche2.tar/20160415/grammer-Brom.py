smiles('C=C(C)C=C', 'Isoprene')
smiles('[Br][Br]', 'Brom')

ruleGML('brom.gml')
