smiles('C=C(C)C=C', 'Isoprene')
ruleGML('DA.gml')
