smiles('CC1=CCC(CC1)C(C)(C)O', 'alpha-terpineol')
ruleGML('cyclisation.gml')
